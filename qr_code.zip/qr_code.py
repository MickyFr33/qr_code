import os
import qrcode
from pyzbar.pyzbar import decode
from PIL import Image
import cv2
import pyfiglet
import matplotlib.pyplot as plt

def create_qr_code():
    # Input data for the QR code
    data = input("Enter data for the QR code: ")
    
    # Generate the QR code image
    img = qrcode.make(data)
    
    # Display the QR code image using Matplotlib
    plt.imshow(img)
    plt.axis('off')
    plt.show()

def decode_qr_code():
    # Input method for decoding (image or camera)
    method = input("Enter method (image/camera): ")
    if method == "image":
        # Decode QR code from image file
        filename = input("Enter filename of the QR code image (include extension): ")
        img = Image.open(filename)
        result = decode(img)
        print("Decoded data:", result[0].data.decode())
    elif method == "camera":
        # Decode QR code from camera stream
        cap = cv2.VideoCapture(0)
        while True:
            _, frame = cap.read()
            result = decode(frame)
            if result:
                print("Decoded data:", result[0].data.decode())
                break
            cv2.imshow("Camera", frame)
            if cv2.waitKey(1) == ord('q'):
                break
        cap.release()
        cv2.destroyAllWindows()
    else:
        print("Invalid method. Please try again.")

def start_menu():
    # Display ASCII art and welcome message
    ascii_art = pyfiglet.figlet_format("Mac's QR Code Tool")
    print(ascii_art)
    print("Welcome to the QR Code Tool!")
    
    # Display menu and process user choice
    while True:
        print("\nMenu:")
        print("1. Create QR code")
        print("2. Decode QR code")
        print("3. Exit")
        choice = input("Enter your choice: ")
        # If/else statements to migrate to correct choice
        if choice == '1':
            create_qr_code()
        # If/else statements to migrate to correct choice    
        elif choice == '2':
            decode_qr_code()
        #breaks the while loop and exits the program    
        elif choice == '3': 
            break
        else:
            print("Invalid choice. Please try again.")

# Start the menu
start_menu()
